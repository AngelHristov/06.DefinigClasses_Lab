﻿namespace CarManufacturer
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            Car car = new Car
            {
                Make = "VW",
                Model = "Golf 2",
                Year = 1985,
                FuelConsumption = 2,
                FuelQuantity = 200
            };

            car.Drive(20);
            Console.WriteLine(car.WhoAmI());
        }
    }
}
